module com.icesi.tictactoe {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.icesi.tictactoe.gui to javafx.fxml;
    opens com.icesi.tictactoe.control to javafx.fxml;
    exports com.icesi.tictactoe.model;
    exports com.icesi.tictactoe.control;
    exports com.icesi.tictactoe.gui;
}