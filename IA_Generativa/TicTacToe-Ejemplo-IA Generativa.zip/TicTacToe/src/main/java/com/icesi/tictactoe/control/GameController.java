package com.icesi.tictactoe.control;

import com.icesi.tictactoe.model.Board;
import com.icesi.tictactoe.model.Cell;
import com.icesi.tictactoe.model.Player;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;


public class GameController {
    @FXML
    private Canvas gameCanvas;

    private Board board;
    private Player currentPlayer;

    public void initialize() {
        board = new Board();
        currentPlayer = new Player("Player 1", 'X');
        gameCanvas.setOnMouseClicked(this::handleClick);
        drawBoard();
    }

    private void handleClick(MouseEvent event) {
        int row = (int) (event.getY() / 100);
        int col = (int) (event.getX() / 100);
        Cell cell = board.getCells()[row][col];

        if (cell.getOwner() == ' ' && !board.isGameOver()) {
            cell.setOwner(currentPlayer.getSymbol());
            drawSymbolInCell();
            board.checkGameOver();
            currentPlayer = (currentPlayer.getSymbol() == 'X') ? new Player("Player 2", 'O') : new Player("Player 1", 'X');
        }
    }

    private void drawBoard() {
        GraphicsContext gc = gameCanvas.getGraphicsContext2D();
        //gc.clearRect(0, 0, gameCanvas.getWidth(), gameCanvas.getHeight());
        gc.strokeLine(100, 0, 100, 300); //(x1, y1, x2, y2)
        gc.strokeLine(200, 0, 200, 300);
        gc.strokeLine(0, 100, 300, 100);
        gc.strokeLine(0, 200, 300, 200);
    }

    private void drawSymbolInCell(){
        GraphicsContext gc = gameCanvas.getGraphicsContext2D();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                Cell cell = board.getCells()[i][j];
                if (cell.getOwner() != ' ') {
                    // Descargar la imagen y cargarla desde resources
                    if(cell.getOwner()=='X'){
                        Image image = new Image("https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.transparentpng.com%2Fcats%2Fcross-2020.html&psig=AOvVaw3U7c5sKUWmtQCcOxz9aqB7&ust=1747316423093000&source=images&cd=vfe&opi=89978449&ved=0CBUQjRxqFwoTCJCd1oeLo40DFQAAAAAdAAAAABAE", 25,25,false, false);
                        gc.drawImage(image,20,20);
                    }
                    gc.strokeText(String.valueOf(cell.getOwner()), j * 100 + 45, i * 100 + 55);
                }
            }
        }
    }
}