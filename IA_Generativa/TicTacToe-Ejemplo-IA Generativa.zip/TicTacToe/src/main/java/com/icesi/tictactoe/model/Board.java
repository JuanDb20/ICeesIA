package com.icesi.tictactoe.model;

public class Board {
    private Cell[][] cells = new Cell[3][3];
    private boolean gameOver = false;

    public Board() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                cells[i][j] = new Cell(i, j);
            }
        }
    }

    public Cell[][] getCells() {
        return cells;
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public void checkGameOver() {
        // Check rows, columns, and diagonals for a winner
        // If a winner is found, set gameOver to true
        // If a draw is found, set gameOver to true
    }
}