package model;

public enum Carreer {

    SIS, TEL, INT, DMI
}
